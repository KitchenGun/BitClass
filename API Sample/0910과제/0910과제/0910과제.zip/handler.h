#pragma once

//send
BOOL OnInitDialog(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL OnOK(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);

//receive
BOOL OnReceiveInitDialog(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL OnReceiveInitDialog(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam); 
BOOL OnCopyDataStruct(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);