#pragma once


void fun_ListViewHeader(HWND hDlg, HWND g_hView);

void fun_ListViewPrint(HWND hDlg);