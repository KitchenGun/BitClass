//member.h
#pragma once


typedef struct tagmemberdata
{
	char id[20];
	char pw[20];
	char name[20];
	int  age;
	bool islogin;
}memberdata;
