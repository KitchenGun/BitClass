//app.h

#pragma once

void app_init();
void app_run();
void app_exit();

void logo();
void ending();
void menuprint();

