//std.h
#pragma once

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
//---------------------- Winsock���� h ------------------------
#include <WinSock2.h>	
#pragma comment(lib, "ws2_32.lib")  
#include <ws2tcpip.h>
#include <process.h>
//-------------------------------------------------------------

#include "packet.h"
#include "app.h"
#include "control.h"
#include "wbclient.h"
