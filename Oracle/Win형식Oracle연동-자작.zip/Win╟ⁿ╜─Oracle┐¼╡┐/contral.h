#pragma once

void con_Init(HWND hDlg);
void con_Exit(HWND hDlg);

void con_InsertAccount(HWND hDlg);

//�޺��ڽ� �ʱ�ȭ
void hComboAdd(HWND hDlg, int id);
void con_comboSelect(HWND hDlg);
//����
void con_DeleteAccount(HWND hDlg);
//����
void con_UpdateBalanceAdv(HWND hDlg);
void con_UpdateBalanceDAdv(HWND hDlg);
//����Ʈ�ڽ� 
void con_ListViewHeader(HWND hDlg, HWND g_hView);
void con_UpdateList(HWND, HWND g_hView);
void con_GetSQLData(HWND, HWND g_hView);