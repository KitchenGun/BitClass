//std.h
#pragma comment (linker, "/subsystem:windows")

#include <Windows.h>
#include <tchar.h>	
#include <sql.h>
#include <sqlext.h>
#include <commctrl.h>		//listview
#include <vector>
#include<string>
#include "resource.h"
#include "handler.h"
#include "contral.h"
#include "wb_db.h"
using namespace std;

typedef struct account
{
	int acc_id;
	TCHAR acc_name[50];
	int acc_balence;
	TCHAR acc_DATE[50];
}ACCOUNT;
