#include "std.h"

#define DBNAME	TEXT("wb32")

SQLHENV hEnv;		//ȯ�� �ڵ�
SQLHDBC hDbc;		//����Ŭ�� ������ �ڵ�
SQLHSTMT hStmt;		//����Ŭ�� �������� ���� �� �ִ� ���� �ڵ�

vector<ACCOUNT> acclist;


BOOL wb_DBConnect(TCHAR* ID, TCHAR* PW)
{

	// ���� ������ ���� ������
	SQLRETURN Ret;

	// 1, ȯ�� �ڵ��� �Ҵ��ϰ� ���� �Ӽ��� �����Ѵ�.(p1741)
	if (SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv) != SQL_SUCCESS)
		return false;
	if (SQLSetEnvAttr(hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER) != SQL_SUCCESS)
		return false;

	// 2. ���� �ڵ��� �Ҵ��ϰ� �����Ѵ�.
	if (SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hDbc) != SQL_SUCCESS)
		return false;
// ����Ŭ ������ �����ϱ�
Ret = SQLConnect(hDbc, (SQLTCHAR*)DBNAME, SQL_NTS, (SQLTCHAR*)ID, SQL_NTS, (SQLTCHAR*)PW, SQL_NTS);

if ((Ret != SQL_SUCCESS) && (Ret != SQL_SUCCESS_WITH_INFO))
return false;

// ���� �ڵ��� �Ҵ��Ѵ�.
if (SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt) != SQL_SUCCESS)
return false;

return true;
}

void wb_DBDisConnect()
{
	// ������
	if (hStmt) SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
	if (hDbc) SQLDisconnect(hDbc);
	if (hDbc) SQLFreeHandle(SQL_HANDLE_DBC, hDbc);
	if (hEnv) SQLFreeHandle(SQL_HANDLE_ENV, hEnv);
}

//insert into account values(accid_seq.nextval, '�̱浿', 10000, sysdate);
int wb_InsertAccout(TCHAR* name, int money)
{
	TCHAR sql[256];
	wsprintf(sql, TEXT("insert into account values(accid_seq.nextval,'%s' ,%d, sysdate)"),
		name, money);
	SQLFetch(hStmt);
	if (SQLExecDirect(hStmt, (SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
		return 0;
	else
	{
		return GetAccid(name);

	}
}

//select accid from account where name = '�̱浿';
int GetAccid(TCHAR* name)
{
	int id = 0;
	SQLINTEGER lid = 0;

	TCHAR sql[256];

	wsprintf(sql, TEXT("select accid from account where name = '%s';"), name);
	SQLBindCol(hStmt, 1, SQL_C_ULONG, &id, 0, &lid);
	if (SQLExecDirect(hStmt, (SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
		return -1;
	SQLFetch(hStmt);
	return id;

}

TCHAR* wb_FindAccName(TCHAR* id)
{

	SQLTCHAR Name[50] = { 0 };
	SQLLEN lname = sizeof(Name);

	TCHAR sql[256];
	wsprintf(sql, TEXT("select NAME from account where accid = %s;"), id);

	SQLBindCol(hStmt, 1, SQL_C_WCHAR, Name, sizeof(Name), &lname);
	SQLFetch(hStmt);
	if (SQLExecDirect(hStmt, (SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
	{
		return NULL;
	}
	else
	{
		SQLFetch(hStmt);
		return (TCHAR*)Name;
	}
}

int wb_FindAccBalance(TCHAR* id)
{

	int money = 0;
	SQLINTEGER lmoney = 0;

	TCHAR sql[256];

	wsprintf(sql, TEXT("select balance from account where accid = '%s';"), id);
	SQLBindCol(hStmt, 1, SQL_C_ULONG, &money, 0, &lmoney);
	SQLFetch(hStmt);
	if (SQLExecDirect(hStmt, (SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
		return -1;
	SQLFetch(hStmt);
	return money;

}

BOOL wb_DeleteAcc(TCHAR* id)
{
	TCHAR sql[256];

	wsprintf(sql, TEXT("delete from account where accid = '%s';"), id);

	SQLFetch(hStmt);
	if (SQLExecDirect(hStmt,(SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
	{
		return false;
	}
	TCHAR msg[50];
	wsprintf(msg, TEXT("%s ����"), id);
	MessageBox(0, msg, TEXT("����"), 0);
	return TRUE;
}

BOOL wb_UpdateBalance(TCHAR* id,int value,bool flag)
{
	TCHAR sql[256];

	int money = wb_FindAccBalance(id);

	if (flag == TRUE)
	{
		money += value;
	}
	else if (flag == FALSE)
	{
		money -= value;
	}
	wsprintf(sql, TEXT("update account set balance = %d where accid = %s;"), money,id);
	SQLFetch(hStmt);
	if (SQLExecDirect(hStmt, (SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
	{
		return false;
	}
	TCHAR msg[50];
	wsprintf(msg, TEXT("%s �����Ϸ�"), id);
	MessageBox(0, msg, TEXT("����"), 0);
	
	return TRUE;
}

BOOL wb_ListAllReset()
{
	account acc;

	int accid, balance;
	SQLTCHAR name[50], date[50];
	SQLINTEGER laccid, lbalance, lname, ldate;

	SQLBindCol(hStmt, 1, SQL_C_ULONG, &accid, 0, &laccid);
	SQLBindCol(hStmt, 2, SQL_C_TCHAR, name, sizeof(name), &lname);
	SQLBindCol(hStmt, 3, SQL_C_ULONG, &balance, 0, &lbalance);
	SQLBindCol(hStmt, 4, SQL_C_TCHAR, &date, sizeof(date), &ldate);

	TCHAR sql[256];
	_tcscpy_s(sql, _countof(sql), TEXT("select * from account order by accid asc;"));

	SQLFetch(hStmt);
	if (SQLExecDirect(hStmt, (SQLTCHAR*)sql, SQL_NTS) != SQL_SUCCESS)
	{
		return -1;
	}
	SQLFetch(hStmt);
	if (!acclist.empty())
	{
		acclist.clear();
	}
	for (int i = 0; SQLFetch(hStmt) != SQL_NO_DATA; i++)
	{
			acc.acc_id = accid;
			_tcscpy_s(acc.acc_name, name);
			acc.acc_balence = balance;
			_tcscpy_s(acc.acc_DATE, date);
			acclist.push_back(acc);
	
	}
	return true;
}