#include "std.h"

BOOL OnInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	con_Init(hDlg);
	HWND g_hView = GetDlgItem(hDlg, IDC_LIST2);
	con_ListViewHeader(hDlg, g_hView);
	return TRUE;
}

BOOL OnCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{ 
	
	switch (LOWORD(wParam))
	{
		case IDC_BUTTON1: con_InsertAccount(hDlg);	break;
		case IDC_BUTTON3: con_UpdateBalanceAdv(hDlg);	break;
		case IDC_BUTTON4: con_UpdateBalanceDAdv(hDlg);	break;
		case IDC_BUTTON5: con_DeleteAccount(hDlg); break;
		case IDC_COMBO1:
			switch (HIWORD(wParam))
			{
				case CBN_SELCHANGE:
					con_comboSelect(hDlg);
					break;
			}
			break;
		case IDCANCEL: con_Exit(hDlg);	return 0;
		
	}

	return TRUE;
}
